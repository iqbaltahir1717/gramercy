
                <!-- footer Start -->
                <footer>
                    <div class="footer clearfix mb-0 text-muted">
                        <div class="float-start">
                            <p>Copyright &copy; <?php echo $setting[0]->setting_short_appname;?> <?= date('Y'); ?>, version 1.0</p>
                        </div>
                        <div class="float-end">
                            <p>Created by <a href="https://instagram.com/fadjrul00"><?php echo $setting[0]->setting_owner_name;?></a></p>
                        </div>
                    </div>
                </footer>
                <!-- footer End -->
            <!-- main content end -->
            </div>
        <!-- layout navbar end -->
        </div>
    <!-- app end -->
    </div>
    <!-- javascript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.js"></script>
    <script src="<?php echo base_url();?>assets/js/app.js"></script>
    <script src="<?php echo base_url();?>assets/extensions/dayjs/dayjs.min.js"></script>
    <script src="<?php echo base_url();?>assets/extensions/toastify-js/src/toastify.js"></script>
    <script src="<?php echo base_url();?>assets/extensions/choices.js/public/assets/scripts/choices.js"></script>
    <script src="<?php echo base_url();?>assets/js/pages/form-element-select.js"></script>
    <script src="<?php echo base_url(); ?>assets/core-thirdparty/ckfinder/ckfinder.js"></script>
    <script src="<?php echo base_url();?>assets/extensions/tinymce/tinymce.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/pages/tinymce.js"></script>
    <script src="<?php echo base_url();?>assets/extensions/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/extensions/datatables.js"></script>
</body>

</html>